package com.example.myapp.hr.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.myapp.hr.service.IEmpService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class EmpController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	IEmpService empService;
	
	@RequestMapping("/hr/count")
	public String empCount(Model model) {
//		System.out.println("empCount 메서드 실행"); // 이런 코드는 넣지 말자
		logger.info("empCunt 메서드 실행");
		log.info("empCount call");
		model.addAttribute("count", empService.getEmpCount());
		return "hr/count";
	}
}
