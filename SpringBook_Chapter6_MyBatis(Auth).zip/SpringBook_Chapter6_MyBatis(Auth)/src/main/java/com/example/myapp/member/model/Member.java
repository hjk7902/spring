package com.example.myapp.member.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter @Getter
@ToString
public class Member {
	private String userid; 	//	USERID VARCHAR2(50) PRIMARY KEY,
	private String name; 	//	NAME VARCHAR2(50) NOT NULL,
	private String password; //	PASSWORD VARCHAR2(150) NOT NULL,
	private String email;	//	EMAIL VARCHAR2(100) NOT NULL,
	private String phone;	//	PHONE VARCHAR2(50),
	private String role;	//	ROLE VARCHAR2(20) DEFAULT 'ROLE_USER'
}
