package com.example.myapp.upload.controller;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.example.myapp.upload.model.UploadFile;
import com.example.myapp.upload.service.IUploadFileService;

@Controller
public class UploadFileController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	IUploadFileService uploadService;
	
	@GetMapping("/file/new")
	public String uploadFile() {
		logger.info("파일 입력 양식을 요청합니다.");
		return "file/form";
	}
	
	@PostMapping("/file/new")
	public String uploadFile(String category, MultipartFile file, HttpSession session) {
		logger.info("{}, {}", category, file.getOriginalFilename());
		String uploadDir = session.getServletContext().getRealPath("/upload"); //"C:/dev/upload";
		logger.info("Upload dir: {}", uploadDir);
		try {
			if(file!=null && !file.isEmpty()) {
				String fileName = file.getOriginalFilename();
				String fileExt = fileName.substring(fileName.lastIndexOf("."));
				UUID uuid = UUID.randomUUID();
				String uuidFileName = uuid + fileExt;
				
				File saveFilePath = new File(uploadDir, uuidFileName);
				byte[] fileData = file.getBytes();
				try(FileOutputStream fos = new FileOutputStream(saveFilePath)) {
					fos.write(fileData);
				}
//				file.transferTo(saveFilePath);
				
				UploadFile newFile = new UploadFile();
				newFile.setCategoryName(category);
				newFile.setFileName(file.getOriginalFilename());
				newFile.setUuidFileName(uuidFileName);
				newFile.setFileSize(file.getSize());
				newFile.setFileContentType(file.getContentType());
				if("image".equals(file.getContentType().split("/")[0])) {
					logger.info("Thumbnail: {} 이미지를 생성합니다.", uuidFileName);
					createThumbnailImage(fileData, uploadDir, uuidFileName, fileExt);
				}
				uploadService.uploadFile(newFile);
			}
		}catch(Exception e) {
			logger.error(e.getMessage());
		}
		return "redirect:/file/list";
	}
	
	@GetMapping("/file/list")
	public String getFileList(Model model) {
		List<UploadFile> fileList = uploadService.getAllFileList();
		model.addAttribute("fileList", fileList);
		return "file/list";
	}
	
	@GetMapping("/file/{fileId}")
	public ResponseEntity<byte[]> getBinaryFile(@PathVariable int fileId, HttpSession session) {
		UploadFile file = uploadService.getFile(fileId);
		if (file == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
		
		String uploadDir = session.getServletContext().getRealPath("/upload"); //"C:/dev/upload";
		Path filePath = Paths.get(uploadDir, file.getUuidFileName());
        if (!Files.exists(filePath)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

		try {
			byte[] fileBytes = Files.readAllBytes(filePath);
			HttpHeaders headers = new HttpHeaders();
			String[] mtype = file.getFileContentType().split("/");
			headers.setContentType(new MediaType(mtype[0], mtype[1]));
			headers.setContentLength(file.getFileSize());
			String encFileName = URLEncoder.encode(file.getFileName(), "UTF-8").replace("+", "%20");
			headers.setContentDispositionFormData("attachment", encFileName);
			return new ResponseEntity<>(fileBytes, headers, HttpStatus.OK);
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving file", e);
		}
	}

	@GetMapping("/file/thumbnail/{fileId}")
	public ResponseEntity<byte[]> getThumbnailImage(@PathVariable int fileId, HttpSession session) {
		UploadFile file = uploadService.getFile(fileId);
		if (file == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
		
		String uploadDir = session.getServletContext().getRealPath("/upload"); //"C:/dev/upload";
		Path filePath = Paths.get(uploadDir, "T-"+file.getUuidFileName());
        if (!Files.exists(filePath)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

		try {
			byte[] fileBytes = Files.readAllBytes(filePath);
			HttpHeaders headers = new HttpHeaders();
			String[] mtype = file.getFileContentType().split("/");
			headers.setContentType(new MediaType(mtype[0], mtype[1]));
			headers.setContentLength(fileBytes.length);
			String encFileName = URLEncoder.encode(file.getFileName(), "UTF-8").replace("+", "%20");
			headers.setContentDispositionFormData("attachment", encFileName);
			return new ResponseEntity<>(fileBytes, headers, HttpStatus.OK);
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving file", e);
		}
	}
	
	@GetMapping("/file/delete/{fileId}")
	public String deleteFile(@PathVariable int fileId, HttpSession session) {
//		String uploadDir = "C:/dev/upload";
		String uploadDir = session.getServletContext().getRealPath("/upload"); //"C:/dev/upload";

		String uuidFileName = uploadService.getUuidFileName(fileId);
		File file = new File(uploadDir, uuidFileName);
		boolean isDeleted = file.delete();
		if(isDeleted) {
			uploadService.deleteFile(fileId);
		}else {
			throw new RuntimeException("파일이 삭제되지 않았습니다.");
		}
		return "redirect:/file/list";
	}
	
	private void createThumbnailImage(byte[] fileData, String uploadDir, String uuidFileName, String fileExt) throws IOException {
		// 바이트 배열을 이미지 객체로 변환
		ByteArrayInputStream imageArray = new ByteArrayInputStream(fileData);
		BufferedImage srcImage = ImageIO.read(imageArray);

		// resize 이미지 크기, 단위 픽셀(pixel)
		int width = 100;
		int height = (int) (((double) width / srcImage.getWidth()) * srcImage.getHeight());
		
		// 원본 이미지를 크기변환한 이미지로 변환
		Image resizeImage = srcImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);

		// 이미지 저장을 위한 BufferedImage 생성
		BufferedImage outputImage = new BufferedImage(width, height, srcImage.getType());

		// Graphics2D를 이용해서 새 이미지에 크기 변환한 이미지를 그려줌
		Graphics2D g = (Graphics2D) outputImage.getGraphics();
		g.drawImage(resizeImage, 0, 0, null);
		g.dispose(); // 그래픽 객체 연결 끊기

		// 이미지를 파일로 저장(파일명은 앞에 T-를 붙여 원본과 구분되게 함)
		File outputFile = new File(uploadDir, "T-"+uuidFileName);
	    ImageIO.write(outputImage, fileExt.substring(1), outputFile);
	    logger.info("Thumbnail: T-{} 이미지가 생성됐습니다.", uuidFileName);
	}
}
