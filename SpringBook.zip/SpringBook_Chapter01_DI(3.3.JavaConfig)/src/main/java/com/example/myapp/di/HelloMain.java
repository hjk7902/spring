package com.example.myapp.di;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.example.myapp.config.AppConfig;

public class HelloMain {

	public static void main(String[] args) {
		System.out.println("JavaConfig Test");
		AbstractApplicationContext context =
				new AnnotationConfigApplicationContext(AppConfig.class);
		HelloController controller = context.getBean(HelloController.class);
		controller.hello("JinKyoung");
		
		HelloService s1 = context.getBean("helloService", HelloService.class);
		HelloService s2 = context.getBean("helloService", HelloService.class);
		System.out.println(s1==s2);
		context.close();
	}
}