package com.example.myapp.aop;

public interface IHelloService {
	String sayHello(String name);
	String sayGoodby(String name);
}
