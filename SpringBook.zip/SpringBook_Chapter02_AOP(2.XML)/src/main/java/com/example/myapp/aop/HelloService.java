package com.example.myapp.aop;

public class HelloService implements IHelloService {

	@Override
	public String sayHello(String name) {
//		HelloLog.log(); // 횡단적 산재
		System.out.println("HelloService.sayHello() 실행");
		int rand = (int)(Math.random() * 10);
		if(rand < 5) {
			throw new RuntimeException("강제예외 발생");
		}
		return "Hello~"+name;
	}

	@Override
	public String sayGoodby(String name) {
		return "Bye~"+name;
	}

}
