package com.example.myapp.di;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class HelloMain {

	public static void main(String[] args) {
		AbstractApplicationContext context =
				new GenericXmlApplicationContext("application-config.xml");
		HelloController controller = context.getBean(HelloController.class);
		controller.hello("JinKyoung");
		HelloService s1 = context.getBean(HelloService.class);
		HelloService s2 = context.getBean(HelloService.class);
		System.out.println(s1==s2);
		context.close();
	}

}