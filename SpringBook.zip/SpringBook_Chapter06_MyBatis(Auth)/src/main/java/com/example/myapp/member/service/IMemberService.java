package com.example.myapp.member.service;

public interface IMemberService {
	String getPassword(String userid);

	String getEmail(String userid);
}
