package com.example.myapp.hr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.myapp.hr.model.Emp;
import com.example.myapp.hr.service.IEmpService;

@RestController
@RequestMapping("/hr2")
public class EmpRestController {
	
	@Autowired
	IEmpService empService;
	
	@GetMapping("/emp/list")
	public List<Emp> getAllEmps() {
		return empService.getEmpList();
	}
	
	@GetMapping("/emp/{empid}")
	public Emp getEmp(@PathVariable int empid) {
		return empService.getEmpInfo(empid);
	}
	
	@PostMapping("/emp/insert")
	public Emp insertEmp(@RequestBody Emp emp) {
		empService.insertEmp(emp);
		return emp;
	}
}