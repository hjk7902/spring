package com.example.myapp.di;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class CustomerMain {

	public static void main(String[] args) {
		AbstractApplicationContext context =
				new GenericXmlApplicationContext("application-config.xml");
		
		Customer cust = context.getBean(Customer.class);
		
		List<String> nameList = cust.getNameList();
		System.out.println(nameList);
		System.out.println();
		
		Set<String> emailList = cust.getEmailList();
		System.out.println(emailList);
		System.out.println();
		
		Map<Integer, String> departmentInfo = cust.getDepartmentInfo();
		System.out.println(departmentInfo);
		System.out.println();
		
		Properties jobInfo = cust.getJobInfo();
		System.out.println(jobInfo);
		context.close();
	}

}