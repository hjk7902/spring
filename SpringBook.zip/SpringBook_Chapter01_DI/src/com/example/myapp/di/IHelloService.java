package com.example.myapp.di;


public interface IHelloService {
	String sayHello(String name);
}
