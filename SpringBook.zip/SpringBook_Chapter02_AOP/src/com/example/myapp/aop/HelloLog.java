package com.example.myapp.aop;

public class HelloLog {
	
	private static boolean isDebug = true;
	
	public static void log() {
		if(isDebug) {
			System.out.println(">>>LOG<<< : " + new java.util.Date());
		}
	}
}
