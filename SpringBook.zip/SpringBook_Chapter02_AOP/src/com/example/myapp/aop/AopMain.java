package com.example.myapp.aop;

public class AopMain {
	public static void main(String[] args) {
//		IHelloService helloService = new HelloService();
		IHelloService helloService = new HelloServiceProxy();
		helloService.sayHello("JK");
	}
}
