package com.example.myapp.hr;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.example.myapp.hr.service.IEmpService;

public class EmpMain {
	public static void main(String[] args) {
		AbstractApplicationContext context =
				new GenericXmlApplicationContext("application-config.xml");
		IEmpService empService = context.getBean(IEmpService.class);
		System.out.println("-- 사원의 수 조회");
		System.out.println("모든 사원의 수 : " + empService.getEmpCount());
		System.out.println("50번 부서 사원의 수 : " + empService.getEmpCount(50));
		
		empService.deleteEmp(101, "NYANG");
		context.close();
	}
}