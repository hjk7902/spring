<template>
  <div class="container">
    <h1>Members Management</h1>
    
    <button @click="openModal(false)" class="add-member-button">Add New Member</button>
    
    <h2>Member List</h2>
    <table class="member-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="member in paginatedMembers" :key="member.id">
          <td>{{ member.id }}</td>
          <td>{{ member.name }}</td>
          <td>{{ member.email }}</td>
          <td>
            <button @click="openModal(true, member)">Edit</button>
            <button @click="confirmDelete(member.id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>

    <div v-if="isModalVisible" class="modal-overlay">
      <div class="modal">
        <div class="modal-content">
          <h2>{{ isEditing ? 'Edit Member' : 'Add New Member' }}</h2>
          <form @submit.prevent="handleSubmit">
            <div class="form-group">
              <label for="name">Name:</label>
              <input v-model="currentMember.name" type="text" id="name" required />
            </div>
            <div class="form-group">
              <label for="email">Email:</label>
              <input v-model="currentMember.email" type="email" id="email" required />
            </div>
            <div class="modal-actions">
              <button type="submit" class="btn-primary">{{ isEditing ? 'Save Changes' : 'Add Member' }}</button>
              <button type="button" @click="closeModal" class="btn-secondary">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <div class="pagination-controls">
      <button :disabled="currentPage === 1" @click="currentPage--">Previous</button>
      <span>Page {{ currentPage }} of {{ totalPages }}</span>
      <button :disabled="currentPage === totalPages" @click="currentPage++">Next</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      members: [],
      currentMember: {},
      isEditing: false,
      isModalVisible: false,
      currentPage: 1,
      itemsPerPage: 10,
    };
  },
  computed: {
    totalPages() {
      return Array.isArray(this.members) ? Math.ceil(this.members.length / this.itemsPerPage) : 0;
    },
    paginatedMembers() {
      if (!Array.isArray(this.members)) return [];
      const start = (this.currentPage - 1) * this.itemsPerPage;
      const end = start + this.itemsPerPage;
      return this.members.slice(start, end);
    },
  },
  methods: {
    async fetchMembers() {
      try {
        const response = await axios.get('http://localhost:8080/api/members');
        console.log('API Response:', response.data);
        
        if (response.data._embedded && response.data._embedded.memberList) {
          this.members = response.data._embedded.memberList;
        } else {
          this.members = [];
        }
      } catch (error) {
        console.error('Error fetching members:', error);
      }
    },
    async addMember() {
      try {
        const response = await axios.post('http://localhost:8080/api/members', this.currentMember);
        this.members.push(response.data);
        this.closeModal();
      } catch (error) {
        console.error('Error adding member:', error);
      }
    },
    async updateMember() {
      try {
        await axios.put(`http://localhost:8080/api/members/${this.currentMember.id}`, this.currentMember);
        const index = this.members.findIndex(m => m.id === this.currentMember.id);
        this.members.splice(index, 1, this.currentMember);
        this.closeModal();
      } catch (error) {
        console.error('Error updating member:', error);
      }
    },
    async confirmDelete(id) {
      if (confirm('Are you sure you want to delete this member?')) {
        this.deleteMember(id);
      }
    },
    async deleteMember(id) {
      try {
        await axios.delete(`http://localhost:8080/api/members/${id}`);
        this.members = this.members.filter(m => m.id !== id);
        alert('Member successfully deleted.');
      } catch (error) {
        console.error('Error deleting member:', error);
      }
    },
    handleSubmit() {
      if (this.isEditing) {
        this.updateMember();
      } else {
        this.addMember();
      }
    },
    openModal(editing = false, member = null) {
      this.isEditing = editing;
      this.currentMember = editing ? { ...member } : { name: '', email: '' };
      this.isModalVisible = true;
    },
    closeModal() {
      this.isModalVisible = false;
      this.currentMember = {};
    },
  },
  mounted() {
    this.fetchMembers();
  },
};
</script>

<style>
.member-table {
  width: 80%;
  margin: 0 auto;
  border-collapse: collapse;
  text-align: center;
}
.member-table th, .member-table td {
  border: 1px solid #000;
  padding: 10px;
}
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}
.modal {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
  width: 400px;
  max-width: 90%;
}
</style>
