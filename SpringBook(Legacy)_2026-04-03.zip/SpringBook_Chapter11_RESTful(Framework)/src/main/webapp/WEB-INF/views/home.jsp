<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page session="false" %>
<html>
<head>
	<title>Home</title>
</head>
<body>
<h1>HR</h1>
<a href="employees/list">Human Resources List</a><br>
<a href="employees/103">Human Resources: Employee 103</a>
</body>
</html>
