<%@ page contentType="text/html; charset=UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>SSE Example</title>
</head>
<body>
<h1>SSE 메시지 처리</h1>
<p>서버에서 5초마다 전송된 메시지를 출력합니다.</p>
<ul id="result"></ul>
<script>
    var ul = document.querySelector("#result");
    var source = new EventSource("/sse_random");

    source.onmessage = function(event) {
        var data = event.data.split("\n");
        var time = parseInt(data[0], 10);
        var random = parseInt(data[1], 10);
        var dateTime = new Date(time);
        var li = document.createElement("li");
        li.textContent = dateTime.toLocaleString() + ", 난수: " + random;
        ul.appendChild(li);
    };

    source.onerror = function() {
        console.log("SSE 연결 종료 또는 오류 발생");
    };

    window.addEventListener("beforeunload", function () {
        console.log("beforeunload");
        source.close();
    });
</script>
</body>
</html>