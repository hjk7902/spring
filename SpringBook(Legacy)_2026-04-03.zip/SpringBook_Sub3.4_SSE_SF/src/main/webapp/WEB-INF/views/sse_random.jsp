<%@ page contentType="text/event-stream; charset=UTF-8"%>
<%@ page import="java.util.Random"%>
<%
	long time = System.currentTimeMillis();
	int random = new Random().nextInt(100);
%>
retry: 5000
data: <%= time %>
data: <%= random %>

