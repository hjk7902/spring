package com.example.myapp.hr;

import java.util.List;
import java.util.Map;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.example.myapp.hr.model.Emp;
import com.example.myapp.hr.service.IEmpService;

public class EmpMain {
	public static void main(String[] args) {
		AbstractApplicationContext context =
				new GenericXmlApplicationContext("application-config.xml");
		IEmpService empService = context.getBean(IEmpService.class);
		System.out.println("-- 사원의 수 조회");
		System.out.println("모든 사원의 수 : " + empService.getEmpCount());
		System.out.println("50번 부서 사원의 수 : " + empService.getEmpCount(50));
		
		System.out.println("-- 103번 사원의 정보를 조회합니다.");
		System.out.println(empService.getEmpInfoMap(103));
		
		System.out.println("-- 사원 전체 정보를 조회합니다.");
		System.out.println(empService.getEmpListMap());
		
		System.out.println("-- 새로운 사원 정보를 입력합니다.");
		Emp emp = new Emp();
		emp.setEmployeeId(210);
		emp.setFirstName("JinKyoung");
		emp.setLastName("Heo");
		emp.setEmail("HEOJK");
		emp.setPhoneNumber("222-222");
		emp.setHireDate(java.sql.Date.valueOf("2024-05-02"));
		emp.setJobId("IT_PROG");
		emp.setSalary(8000);
		emp.setCommissionPct(0.2);
		emp.setManagerId(100);
		emp.setDepartmentId(10);
		try {
			empService.insertEmp(emp);
			System.out.println("insert ok");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}

		System.out.println("-- 신규 사원의 정보를 조회/출력합니다.");
		Map<String, Object> emp210 = empService.getEmpInfoMap(210);
		System.out.println(emp210);	
		
		// Map의 데이터를 Emp(DTO)에 매핑합니다.
		emp.setEmployeeId(Integer.valueOf(emp210.get("EMPLOYEEID").toString()));
		emp.setFirstName(emp210.get("FIRSTNAME").toString());
		emp.setLastName(emp210.get("LASTNAME").toString());
		emp.setEmail(emp210.get("EMAIL").toString());
		emp.setPhoneNumber(emp210.get("PHONENUMBER").toString());
		emp.setHireDate(java.sql.Date.valueOf("2024-05-02"));
		emp.setJobId(emp210.get("JOBID").toString());
		emp.setSalary(Double.valueOf(emp210.get("SALARY").toString()));
		emp.setCommissionPct(Double.valueOf(emp210.get("COMMISSIONPCT").toString()));
		emp.setManagerId(Integer.valueOf(emp210.get("MANAGERID").toString()));
		emp.setDepartmentId(Integer.valueOf(emp210.get("DEPARTMENTID").toString()));

		System.out.println("-- 210번 사원의 급여를 10% 인상합니다.");
		emp.setSalary(emp.getSalary()*1.1); //급여 정보 수정: 10%인상
		empService.updateEmp(emp);

		System.out.println("-- 수정된 사원의 정보를 조회/출력합니다.");
		emp210 = empService.getEmpInfoMap(210);
		System.out.println(emp210);
		
		System.out.println("-- 210번 사원의 정보를 삭제합니다.");
		int rowCount = empService.deleteEmp(210, "HEOJK");
		System.out.println(rowCount + "개 행이 삭제되었습니다.");
		
		System.out.println("-- 모든 부서번호와 부서이름 정보를 출력합니다.");
		System.out.println(empService.getAllDeptId());
		
		System.out.println("-- 모든 직무아이디와 직무타이틀을 출력합니다.");
		System.out.println(empService.getAllJobId());
		
		System.out.println("-- 모든 매니저번호와 매니저이름을 출력합니다.");
		System.out.println(empService.getAllManagerId());
		
		List<Map<String, Object>> deptInfo = empService.getAllDeptId();
		for(Map<String, Object> deptId : deptInfo) {
			System.out.print(deptId.get("DEPARTMENTID") + "\t");
			System.out.println(deptId.get("DEPARTMENTNAME"));
		}
		
		System.out.println("-- 매퍼를 이용해서 사원 정보를 조회합니다.");
		Emp searchEmp = empService.getEmpInfo(100);
		System.out.println(searchEmp);
		
		context.close();
	}
}