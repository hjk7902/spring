package com.example.myapp.websocket.handler;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RandomNumberWebSocketHandler extends TextWebSocketHandler implements InitializingBean {

    private Set<WebSocketSession> sessionSet = new HashSet<>();

    public RandomNumberWebSocketHandler() {
        log.info("웹소캣 핸들러 인스턴스 생성");
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        sessionSet.add(session);
        log.info("새 접속 세션 추가");
    }

    @Override
    public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {
        log.info("수신 메시지:" + message.toString());
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        sessionSet.remove(session);
        log.info("접속 세션 삭제");
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        log.error("웹소켓 에러!", exception);
    }

    private class RandomRunnable implements Runnable {
        @Override
        public void run() {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    long time = System.currentTimeMillis();
                    int random = ThreadLocalRandom.current().nextInt(0, 100); // ⭐ 변경 포인트

                    for (WebSocketSession session : sessionSet) {
                        if (session.isOpen()) {
                            TextMessage message = new TextMessage(
                                "{\"time\":" + time + ", \"value\":" + random + "}"
                            );
                            session.sendMessage(message);
                        }
                    }

                    Thread.sleep(5000);

                } catch (InterruptedException e) {
                    log.error("쓰레드 중단!", e);
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    log.error("메시지 전송 실패!", e);
                }
            }
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Thread t = new Thread(new RandomRunnable());
        t.start();
    }
}