<%@ page contentType="text/html; charset=UTF-8"%>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>WebSocket Example</title>
</head>
<body>
<h1>웹소켓 메시지 처리</h1>
<p>서버에서 5초마다 전송된 메시지를 출력합니다.</p>
<ul id="result"></ul>
<script>
var ul = document.querySelector("#result")
var ws = new WebSocket("ws://localhost:8080/ws/random");
ws.onmessage = function(event) {
	var data = JSON.parse(event.data);
	console.log(data);
	var dateTime = new Date(data.time);
	var li = document.createElement("li");
	li.textContent = dateTime + ", 난수: " + data.value;
	ul.appendChild(li);
}
</script>
</body>
</html>
