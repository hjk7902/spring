package com.example.myapp.hr;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="No such employee")
public class EmpNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -5677184801060457789L;

	public EmpNotFoundException(String message) {
		super(message);
	}
}
