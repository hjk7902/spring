package com.example.myapp.aop;

public interface IHelloService {
	String sayHello(String name);
	String sayGoodbye(String name);
}
