package com.example.myapp.upload.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.myapp.upload.dao.IUploadFileRepository;
import com.example.myapp.upload.model.UploadFile;

@Service
public class UploadService implements IUploadFileService {

	@Autowired
	IUploadFileRepository uploadFileRepository;
	
	@Override
	public void uploadFile(UploadFile file) {
		int fileId = uploadFileRepository.getMaxFileId();
		file.setFileId(fileId+1);
		uploadFileRepository.uploadFile(file);
	}

	@Override
	public List<UploadFile> getAllFileList() {
		return uploadFileRepository.getAllFileList();
	}

	@Override
	public UploadFile getFile(int fileId) {
		return uploadFileRepository.getFile(fileId);
	}

	@Override
	public void deleteFile(int fileId) {
		uploadFileRepository.deleteFile(fileId);
	}

//	@Transactional
//	public void updateCategory(int[] fileIds, String categoryName) {
//		for(int fileId : fileIds) {
//			HashMap<String, Object> map = new HashMap<String, Object>();
//			map.put("fileId", fileId);
//			map.put("categoryName", categoryName);
//			uploadFileRepository.updateCategory(map);
//		}
//	}
}
