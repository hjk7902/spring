// Vue 3 Composition API + Axios를 사용한 EMPLOYEES 테이블 CRUD 구현

<template>
  <div class="container">
    <h1>Employees Management</h1>

    <!-- Add Employee Form -->
    <form @submit.prevent="addEmployee">
      <h2>Add New Employee</h2>
      <label for="employeeId">Employee ID:</label>
      <input v-model="newEmployee.employeeId" type="text" id="employeeId" required />

      <label for="firstName">First Name:</label>
      <input v-model="newEmployee.firstName" type="text" id="firstName" required />

      <label for="lastName">Last Name:</label>
      <input v-model="newEmployee.lastName" type="text" id="lastName" required />

      <label for="email">Email:</label>
      <input v-model="newEmployee.email" type="text" id="email" required />

      <label for="phoneNumber">Phone Number:</label>
      <input v-model="newEmployee.phoneNumber" type="text" id="phoneNumber" required />

      <label for="jobId">Job ID:</label>
      <select v-model="newEmployee.jobId" id="jobId" required>
        <option value="" disabled>선택하세요.</option>
        <option v-for="job in jobs" :key="job.jobId" :value="job.jobId">
          {{ job.jobTitle }}
        </option>
      </select>

      <label for="hireDate">Hire Date:</label>
      <input v-model="newEmployee.hireDate" type="date" id="hireDate" required />

      <label for="salary">Salary:</label>
      <input v-model="newEmployee.salary" type="number" id="salary" required />

      <label for="commissionPct">Commission Pct:</label>
      <input v-model="newEmployee.commissionPct" type="number" id="commissionPct" />

      <label for="managerId">Manager ID:</label>
      <select v-model="newEmployee.managerId" id="managerId">
        <option value="" disabled>선택하세요.</option>
        <option v-for="manager in managers" :key="manager.managerId" :value="manager.managerId">
          {{ manager.managerName }}
        </option>
      </select>

      <label for="departmentId">Department:</label>
      <select v-model="newEmployee.departmentId" id="departmentId" required>
        <option value="" disabled>선택하세요.</option>
        <option v-for="department in departments" :key="department.departmentId" :value="department.departmentId">
          {{ department.departmentName }}
        </option>
      </select>

      <button type="submit">Add Employee</button>
    </form>

    <!-- Employee List -->
    <h2>Employee List</h2>
    <table>
      <thead>
        <tr>
          <th>Employee ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>Phone Number</th>
          <th>Job ID</th>
          <th>Hire Date</th>
          <th>Salary</th>
          <th>Commission Pct</th>
          <th>Manager ID</th>
          <th>Department ID</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="employee in paginatedEmployees" :key="employee.employeeId">
          <td>{{ employee.employeeId }}</td>
          <td>{{ employee.firstName }}</td>
          <td>{{ employee.lastName }}</td>
          <td>{{ employee.email }}</td>
          <td>{{ employee.phoneNumber }}</td>
          <td>{{ employee.jobId }}</td>
          <td>{{ employee.hireDate }}</td>
          <td>{{ employee.salary }}</td>
          <td>{{ employee.commissionPct }}</td>
          <td>{{ employee.managerId }}</td>
          <td>{{ employee.departmentId }}</td>
          <td>
            <button @click="editEmployee(employee)">Edit</button>
            <button @click="promptDelete(employee.employeeId, employee.email)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Pagination Controls -->
    <div class="pagination-controls">
      <button :disabled="currentPage === 1" @click="currentPage--">Previous</button>
      <span>Page {{ currentPage }} of {{ totalPages }}</span>
      <button :disabled="currentPage === totalPages" @click="currentPage++">Next</button>
    </div>

    <!-- Edit Employee Modal -->
    <div v-if="isEditing" class="modal">
      <h2>Edit Employee</h2>
      <form @submit.prevent="updateEmployee">
        <label for="edit-employeeId">Employee ID:</label>
        <input v-model="currentEmployee.employeeId" type="text" id="edit-employeeId" disabled />

        <label for="edit-firstName">First Name:</label>
        <input v-model="currentEmployee.firstName" type="text" id="edit-firstName" required />

        <label for="edit-lastName">Last Name:</label>
        <input v-model="currentEmployee.lastName" type="text" id="edit-lastName" required />

        <label for="edit-email">Email:</label>
        <input v-model="currentEmployee.email" type="text" id="edit-email" required />

        <label for="edit-phoneNumber">Phone Number:</label>
        <input v-model="currentEmployee.phoneNumber" type="text" id="edit-phoneNumber" required />

        <label for="edit-jobId">Job ID:</label>
        <select v-model="currentEmployee.jobId" id="edit-jobId" required>
          <option v-for="job in jobs" :key="job.jobId" :value="job.jobId">
            {{ job.jobTitle }}
          </option>
        </select>

        <label for="edit-hireDate">Hire Date:</label>
        <input v-model="currentEmployee.hireDate" type="date" id="edit-hireDate" required />

        <label for="edit-salary">Salary:</label>
        <input v-model="currentEmployee.salary" type="number" id="edit-salary" required />

        <label for="edit-commissionPct">Commission Pct:</label>
        <input v-model="currentEmployee.commissionPct" type="number" id="edit-commissionPct" />

        <label for="edit-managerId">Manager ID:</label>
        <select v-model="currentEmployee.managerId" id="edit-managerId">
          <option v-for="manager in managers" :key="manager.managerId" :value="manager.managerId">
            {{ manager.managerName }}
          </option>
        </select>

        <label for="edit-departmentId">Department:</label>
        <select v-model="currentEmployee.departmentId" id="edit-departmentId" required>
          <option v-for="department in departments" :key="department.departmentId" :value="department.departmentId">
            {{ department.departmentName }}
          </option>
        </select>

        <button type="submit">Save Changes</button>
        <button type="button" @click="isEditing = false">Cancel</button>
      </form>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      employees: [],
      departments: [],
      jobs: [],
      managers: [],
      newEmployee: this.getDefaultEmployee(),
      currentEmployee: {},
      isEditing: false,
      currentPage: 1,
      itemsPerPage: 10,
    };
  },
  computed: {
    totalPages() {
      return Math.ceil(this.employees.length / this.itemsPerPage);
    },
    paginatedEmployees() {
      const start = (this.currentPage - 1) * this.itemsPerPage;
      const end = start + this.itemsPerPage;
      return this.employees.slice(start, end);
    },
  },
  methods: {
    getDefaultEmployee() {
      return {
        firstName: '',
        lastName: '',
        email: '',
        phoneNumber: '',
        jobId: '',
        hireDate: '',
        salary: null,
        commissionPct: null,
        managerId: null,
        departmentId: null
      };
    },
    async fetchData(endpoint, targetProperty) {
      try {
        const response = await axios.get(endpoint);
        this[targetProperty] = response.data;
      } catch (error) {
        console.error(`Error fetching data from ${endpoint}:`, error);
      }
    },
    async addEmployee() {
      try {
        const response = await axios.post('http://localhost:8080/employees', this.newEmployee);
        this.employees.push(response.data);
        this.newEmployee = this.getDefaultEmployee();
      } catch (error) {
        console.error('Error adding employee:', error);
      }
    },
    editEmployee(employee) {
      this.currentEmployee = { ...employee };
      this.isEditing = true;
    },
    async updateEmployee() {
      try {
        await axios.put('http://localhost:8080/employees', this.currentEmployee);
        const index = this.employees.findIndex(e => e.employeeId === this.currentEmployee.employeeId);
        this.employees.splice(index, 1, this.currentEmployee);
        this.isEditing = false;
        this.currentEmployee = {};
      } catch (error) {
        console.error('Error updating employee:', error);
      }
    },
    async promptDelete(employeeId, email) {
      const userInput = prompt('Please enter the email of the employee to confirm deletion:');
      if (userInput && userInput === email) {
        try {
          await axios.delete(`http://localhost:8080/employees?empid=${employeeId}&email=${email}`);
          this.employees = this.employees.filter(e => e.employeeId !== employeeId);
          alert('Employee successfully deleted.');
        } catch (error) {
          console.error('Error deleting employee:', error);
        }
      } else {
        alert('Email does not match. Deletion canceled.');
      }
    }
  },
  mounted() {
    this.fetchData('http://localhost:8080/employees', 'employees');
    this.fetchData('http://localhost:8080/employees/jobids', 'jobs');
    this.fetchData('http://localhost:8080/employees/mgrids', 'managers');
    this.fetchData('http://localhost:8080/employees/deptids', 'departments');
  }
};
</script>

<style>
.container {
  max-width: 800px;
  margin: auto;
  padding: 20px;
}

form {
  margin-bottom: 20px;
}

label {
  display: block;
  margin: 10px 0 5px;
}

input {
  width: 100%;
  padding: 8px;
  margin-bottom: 10px;
  box-sizing: border-box;
}

button {
  margin-right: 10px;
  padding: 8px 15px;
  cursor: pointer;
}

table {
  width: 100%;
  border-collapse: collapse;
}

table th, table td {
  border: 1px solid #ddd;
  padding: 8px;
}

table th {
  background-color: #f4f4f4;
  text-align: left;
}

.modal {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: white;
  padding: 20px;
  border: 1px solid #ddd;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.pagination-controls {
  margin-top: 20px;
  text-align: center;
}

.pagination-controls button {
  margin: 0 5px;
  padding: 5 px 10px;
}
</style>
