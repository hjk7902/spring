package com.example.myapp.di;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Customer {
	private List<String> nameList;
	private Set<String> emailList;
	private Map<Integer, String> departmentInfo; 
	private Properties jobInfo;
}
